/*
 * uart.h
 *
 *  Created on: Jan 19, 2023
 *      Author: hussamaldean
 */

#ifndef UART_H_
#define UART_H_

#include "stdio.h"

void uart2_init();


#endif /* UART_H_ */
